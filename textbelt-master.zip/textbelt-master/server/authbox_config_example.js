module.exports = {
  apiKey: 'foobar',
  secretKey: '1234567'
};
