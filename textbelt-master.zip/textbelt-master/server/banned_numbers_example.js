// People are added to this list if they contact Textbelt when someone is
// abusing the service.

exports = module.exports = {
  BLACKLIST: {
    "9145555555": true,
  }
}
