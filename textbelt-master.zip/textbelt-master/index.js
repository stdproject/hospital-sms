var textbelt = require('./lib/text');

module.exports = textbelt;
